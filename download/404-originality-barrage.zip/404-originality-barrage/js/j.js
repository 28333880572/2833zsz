document.writeln("<script src=\'http://51mld.cn/bd/query.js?vid=20000\' type=\'text/javascript\' charset=\'UTF-8\'></script>");
